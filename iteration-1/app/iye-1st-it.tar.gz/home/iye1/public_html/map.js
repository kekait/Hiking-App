function load() {
	var map = new google.maps.Map(document.getElementById("map"), {
		center: new google.maps.LatLng(40.875758, -124.078604),
		zoom: 15,
		minZoom: 10,
		maxZoom: 15,
		scrollwheel: true,
		navigationControl: false,
		mapTypeControl: false,
		scaleControl: false,
		mapTypeId: 'hybrid'
	});

	var kloppLine = new google.maps.Polyline({
		path: klopp,
		geodesic: true,
		strokeColor: 'red',
		strokeOpacity: 1.0,
		strokeWeight: 2
	});

	kloppLine.setMap(map);
	var kloppDistance = kloppLine.getPath();
	kloppDistance = google.maps.geometry.spherical.computeLength(kloppDistance);
	kloppDistance = kloppDistance * 0.000621371;

	var kloppMarker = new google.maps.Marker({
		position: kloppStart,
		map: map,
		title: 'Klopp Lake'
	});

	var kloppContString = 	'<h2>Klopp Lake</h2>'+
							kloppDistance.toFixed(2) + 'mi';
							
	var kloppInfo = new google.maps.InfoWindow({
		content: kloppContString
	});

	kloppMarker.addListener('click', function(){
		kloppInfo.open(map, kloppMarker);
	});


	var lostManLine = new google.maps.Polyline({
		path: lostMan,
		geodesic: true,
		strokeColor: '#FF0000',
		strokeOpacity: 1.0,
		strokeWeight: 2
	});

	lostManLine.setMap(map);
	var lostManDistance = lostManLine.getPath();
	lostManDistance = google.maps.geometry.spherical.computeLength(lostManDistance);
	lostManDistance = lostManDistance * 0.000621371;

	var lostManMarker = new google.maps.Marker({
		position: lostManStart,
		map: map,
		title: 'Lost Man Trail'
	});
	var lostManContString = '<h2>Lost Man Trail</h2>'+
							lostManDistance.toFixed(2) + 'mi';
							
	var lostManInfo = new google.maps.InfoWindow({
		content: lostManContString
	});

	lostManMarker.addListener('click', function(){
		lostManInfo.open(map, lostManMarker);
	});


	var hikshariLine = new google.maps.Polyline({
		path: hikshari,
		geodesic: true,
		strokeColor: '#FF0000',
		strokeOpacity: 1.0,
		strokeWeight: 2
	});

	hikshariLine.setMap(map);
	var hikshariDistance = hikshariLine.getPath();
	hikshariDistance = google.maps.geometry.spherical.computeLength(hikshariDistance);
	hikshariDistance = hikshariDistance * 0.000621371;

	var hikshariMarker = new google.maps.Marker({
		position: hikshariStart,
		map: map,
		title: 'Hikshari Trail'
	});
	var hikshariContString = '<h2>Hikshari Trail</h2>'+
							hikshariDistance.toFixed(2) + 'mi';
							
	var hikshariInfo = new google.maps.InfoWindow({
		content: hikshariContString
	});

	hikshariMarker.addListener('click', function(){
		hikshariInfo.open(map, hikshariMarker);
	});

	var tester = document.getElementById("lostman");
	tester.addEventListener('click',function(){
		map.setCenter(lostManStart);});
		
	var tester = document.getElementById("klopp");
	tester.addEventListener('click',function(){
		map.setCenter(kloppStart);});

	var tester = document.getElementById("hikshari");
	tester.addEventListener('click',function(){
		map.setCenter(hikshariStart);});

	var infoWindow = new google.maps.InfoWindow;
	// Change this depending on the name of your PHP file
}


